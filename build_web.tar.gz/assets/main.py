import asyncio
import json
import pygame
import random
import math
import sys
from collections import deque
from contextlib import closing
from pathlib import Path
from functools import lru_cache
from urllib.parse import parse_qs

# "emscripten" is the name Python reports when it runs inside a web page.
IS_WEB = sys.platform == "emscripten"
if IS_WEB:
    import platform  # In the browser, this module gives access to the web page.
    STORAGE_ERRORS = (Exception,)
else:
    import sqlite3
    import webbrowser
    STORAGE_ERRORS = (sqlite3.Error, OSError)

pygame.init()

WIDTH = 800
HEIGHT = 600

screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("飞行搭档")

# In the browser version, the assets folder sits right beside this file.
GAME_FOLDER = Path(__file__).resolve().parent
ASSETS = GAME_FOLDER / "assets" if (GAME_FOLDER / "assets").is_dir() else GAME_FOLDER.parent / "assets"

clock = pygame.time.Clock()

# A bundled pixel font looks the same on every computer. Its letters are designed
# on a 12-pixel grid, so it stays crisp when enlarged by a whole number.
FONT_PATH = ASSETS / "fonts" / "fusion-pixel-12px-proportional-zh_hans.ttf"
pixel_font = pygame.font.Font(str(FONT_PATH), 12)

# The interface palette borrows the red, cream and dark outline of the plane art.
INK = (52, 32, 20)
CREAM = (255, 241, 208)
SAND = (247, 214, 158)
RED = (226, 52, 52)
DARK_RED = (158, 28, 44)
SUN = (255, 200, 62)
LEAF = (72, 138, 66)
FOREST = (38, 96, 58)
SHADOW = (52, 32, 20, 120)


@lru_cache(maxsize=256)
def render_game_text(text, scale, color, outline=None):
    # Render small, sharp letters, then enlarge each pixel by a whole number.
    label = pixel_font.render(text, False, color).convert_alpha()
    if outline is not None:
        edge = pixel_font.render(text, False, outline).convert_alpha()
        outlined = pygame.Surface(
            (label.get_width() + 2, label.get_height() + 2), pygame.SRCALPHA
        )
        for x in range(3):
            for y in range(3):
                outlined.blit(edge, (x, y))
        outlined.blit(label, (1, 1))
        label = outlined
    return pygame.transform.scale(
        label, (label.get_width() * scale, label.get_height() * scale)
    )


def draw_text(text, scale, center, color=INK, outline=None):
    label = render_game_text(text, scale, color, outline)
    screen.blit(label, label.get_rect(center=center))


def draw_pixel_panel(rect, fill=CREAM, border=INK, shadow=6):
    # Two overlapping rectangles leave stepped corners, like a block of pixels.
    def stepped(area, color, target=screen):
        pygame.draw.rect(target, color, area.inflate(-8, 0))
        pygame.draw.rect(target, color, area.inflate(0, -8))

    if shadow:
        layer = pygame.Surface(rect.size, pygame.SRCALPHA)
        stepped(layer.get_rect(), SHADOW, layer)
        screen.blit(layer, rect.move(shadow, shadow))
    stepped(rect, border)
    stepped(rect.inflate(-8, -8), fill)


SCORE_DATABASE = GAME_FOLDER.parent / "data" / "scores.sqlite3"
WEB_SCORE_KEY = "flight_friends_best_score"
PLAYER_ID = "local_player"
best_score = 0
score_storage_available = True
new_best = False
paused = False
paused_plane = None


def load_best_score(database_path=SCORE_DATABASE, player_id=PLAYER_ID):
    if IS_WEB:
        # A browser cannot keep a database file, but each player's browser can
        # remember a small value in localStorage.
        saved = platform.window.localStorage.getItem(WEB_SCORE_KEY)
        return int(saved) if saved else 0
    database_path.parent.mkdir(parents=True, exist_ok=True)
    with closing(sqlite3.connect(database_path)) as connection:
        with connection:
            connection.execute("""
                CREATE TABLE IF NOT EXISTS player_scores (
                    player_id TEXT PRIMARY KEY,
                    best_score INTEGER NOT NULL CHECK (best_score >= 0)
                )
            """)
        row = connection.execute(
            "SELECT best_score FROM player_scores WHERE player_id = ?",
            (player_id,)
        ).fetchone()
    return row[0] if row else 0


def save_best_score(score, database_path=SCORE_DATABASE, player_id=PLAYER_ID):
    if IS_WEB:
        platform.window.localStorage.setItem(WEB_SCORE_KEY, str(score))
        return
    with closing(sqlite3.connect(database_path)) as connection:
        with connection:
            connection.execute("""
                INSERT INTO player_scores (player_id, best_score) VALUES (?, ?)
                ON CONFLICT(player_id) DO UPDATE SET
                    best_score = MAX(player_scores.best_score, excluded.best_score)
            """, (player_id, score))


def update_best_score():
    global best_score, new_best, score_storage_available
    if score > best_score:
        best_score = score
        new_best = True
        try:
            save_best_score(best_score)
        except STORAGE_ERRORS:
            # Keep the game playable if the database cannot be written.
            score_storage_available = False

boom_text = render_game_text("BOOM!", 1, (255, 240, 120))
boom_shadow = render_game_text("BOOM!", 1, INK)

# -------------------------
# Bird settings
# -------------------------
bird_x = 150
bird_y = 300
bird_radius = 20
plane_size = 80  # Visual size; the collision box stays the same.

bird_image_path = ASSETS / "plane.png"
bird_image = pygame.image.load(str(bird_image_path)).convert_alpha()
bird_image = pygame.transform.scale(
    bird_image, (plane_size, plane_size)
)

head_height = 48
# Every pet lives in a data file, so adding one does not mean changing the game code.
PETS = json.loads((ASSETS / "pets.json").read_text(encoding="utf-8"))
# Each character stores a name, a picture and an introduction split into two lines.
CHARACTERS = tuple((pet["name"], pet["image"], tuple(pet["intro"])) for pet in PETS)
PET_INDEX_BY_ID = {pet["id"]: index for index, pet in enumerate(PETS)}
# Founders always have a card on the first screen; starters are unlocked from the start.
FOUNDER_PETS = [index for index, pet in enumerate(PETS) if pet["founder"]]
STARTER_PETS = [index for index, pet in enumerate(PETS) if pet["starter"]]


def load_character_image(filename):
    path = ASSETS / filename
    head = pygame.image.load(str(path)).convert_alpha()
    # Ignore nearly invisible edge pixels, keeping a margin for soft hair edges.
    bounds = head.get_bounding_rect(min_alpha=16).inflate(4, 4).clip(head.get_rect())
    return head.subsurface(bounds).copy()


def scale_character_head(head, height):
    width = round(height * head.get_width() / head.get_height())
    return pygame.transform.smoothscale(head, (width, height))


def fit_character_portrait(head, height, maximum_width):
    # Wide heads shrink a little more, so every portrait fits inside its card.
    portrait = scale_character_head(head, height)
    if portrait.get_width() > maximum_width:
        # int() rounds down, so the new width can never go past the limit.
        fitted_height = int(maximum_width * head.get_height() / head.get_width())
        portrait = scale_character_head(head, fitted_height)
    return portrait


character_images = [load_character_image(filename) for _, filename, _ in CHARACTERS]
character_heads = [scale_character_head(head, head_height) for head in character_images]
character_portraits = [fit_character_portrait(head, 76, 72) for head in character_images]
selected_character = 0
pilot_head = character_heads[selected_character]
# Two rows of four cards. However many pets exist, this screen never grows.
character_cards = [pygame.Rect(18 + column * 192, top, 188, 128)
                   for top in (122, 258) for column in range(4)]
album_card = character_cards[7]
# Six cards never change, starting with the first pet in the data file. The seventh
# shows the latest partner chosen from the album, and the eighth opens the album.
FIXED_SLOT_PETS = tuple(FOUNDER_PETS[:6])
partner_slot_pet = FOUNDER_PETS[6]
linked_pet = None  # The pet whose own link opened the game; it takes the first card.
album_open = False
album_page = 0
album_previous_button = pygame.Rect(90, 396, 130, 44)
album_next_button = pygame.Rect(580, 396, 130, 44)
start_button = pygame.Rect(200, 448, 400, 52)
# Addresses live in a settings file. An empty form address keeps the button hidden.
UPLOAD_FORM_URL = json.loads((ASSETS / "site.json").read_text(encoding="utf-8"))["form_url"]
upload_button = pygame.Rect(600, 24, 188, 44)
# Pet collection: which pets this player owns, and how close the next dog is.
PROGRESS_FILE = GAME_FOLDER.parent / "data" / "pet_progress.json"
WEB_PROGRESS_KEY = "flight_friends_pets"
pillars_for_first_dogs = (10, 40)  # Count of pillars passed before each of the first dogs.
# After those, the gap shrinks as the album grows, so a big album stays worth collecting.
pillars_for_whole_album = 1500
fewest_pillars_between_dogs = 40
most_pillars_between_dogs = 200
recent_pet_chance = 0.25  # How often the newest locked pet is picked, so new pets get met.
next_dog = None  # Stays the same until it is found, so a crash brings the same friend back.
dog_message_duration = 150  # Frames the in-flight message stays on screen.
celebration_duration = 40  # Frames the rings around the plane last.
CONFETTI_COLORS = (SUN, RED, CREAM, LEAF, (120, 190, 255))
album_page_size = 8
unlocked_pets = set(STARTER_PETS)
pillars_since_dog = 0
newly_found_dogs = []
runs_this_visit = 0
run_started_at = 0
dog_message_frames = 0
newest_dog = None
celebration_frames = 0
confetti_pieces = []
welcome_pet = None
head_sway_speed = 2  # side-to-side cycles per second
head_sway_angle = 8  # Gentle sway while leaning out of the cockpit.
plane_tilt_per_speed = 1.5  # Degrees of tilt for each pixel per frame of speed.

bird_velocity = 0
gravity = 0.25  # Gentler acceleration gives the player more time to react.
jump_strength = -5
maximum_fall_speed = 5  # Pixels per frame; never accelerate into a steep plunge.

death_started_at = None
death_duration = 900  # milliseconds
shake_duration = 0.55  # seconds
shake_strength = 18  # Pixels the picture jumps at the moment of impact.
explosion_particles = []
death_image = None

# -------------------------
# Pipe settings
# -------------------------
pipe_width = 80
# Every point makes the game the same tiny bit harder, with no sudden stages.
# The limits sit around 250 points and only keep the game physically possible.
starting_pipe_gap = 280
minimum_pipe_gap = 160
gap_reduction_per_point = 0.5
starting_pipe_speed = 5.5
maximum_pipe_speed = 8
speed_increase_per_point = 0.01
# How much of the plane's reach the next opening may use.
starting_shift_margin = 0.45
maximum_shift_margin = 0.7
shift_margin_increase_per_point = 0.001
pipe_scroll_remainder = 0.0
pipe_spacing = 300  # Horizontal distance from one obstacle to the next.

pipes = []

# -------------------------
# Scenery settings
# -------------------------
points_per_theme = 15  # The sky changes each time the player earns this many points.
theme_fade_frames = 90
SKY_THEMES = (
    # Meadow morning.
    {"sky": ((132, 208, 186), (214, 234, 184), (255, 240, 190)), "body": (255, 226, 112),
     "stars": 0, "cloud": (255, 255, 244), "far": (128, 176, 158), "snow": (238, 246, 228),
     "near": (92, 164, 84), "tree": (50, 118, 70), "tint": None, "ground": (72, 142, 70)},
    # Golden evening.
    {"sky": ((236, 120, 92), (255, 176, 104), (255, 226, 150)), "body": (255, 240, 170),
     "stars": 0, "cloud": (255, 214, 176), "far": (176, 106, 104), "snow": (255, 220, 190),
     "near": (130, 132, 62), "tree": (78, 88, 48), "tint": (255, 214, 176),
     "ground": (104, 108, 52)},
    # Starry forest night, with fireflies.
    {"sky": ((14, 22, 58), (28, 46, 88), (54, 88, 104)), "body": (245, 240, 210),
     "stars": 90, "cloud": (66, 84, 122), "far": (36, 56, 92), "snow": (120, 142, 170),
     "near": (28, 72, 66), "tree": (14, 46, 50), "tint": (110, 130, 176),
     "ground": (20, 54, 54)},
)
current_theme = 0
previous_theme = None
theme_fade = 1.0
page_theme = 0
world_scroll = 0.0
flap_puffs = []
score_pop_frames = 0
ambient_frames = 0  # Counts animation frames, and stops while the game is paused.


# -------------------------
# Pixel animals
# -------------------------
# Each letter is one pixel and "." is see-through, so the art can be edited as text.
SPRITE_COLORS = {
    "K": INK, "O": (240, 138, 52), "o": (204, 98, 38), "W": (255, 244, 222),
    "B": (28, 18, 18), "P": (244, 150, 160), "L": (232, 226, 214), "G": (172, 166, 158),
    "T": (214, 170, 118), "t": (150, 100, 62), "D": (96, 62, 42), "Y": (255, 214, 80),
    "y": (245, 146, 50), "E": (116, 194, 88), "e": (72, 144, 72), "V": (128, 102, 168),
    "v": (88, 70, 126), "R": (226, 72, 72), "S": (92, 158, 204), "s": (250, 196, 76),
}


def changed_rows(rows, changes):
    # Copy a picture and replace a few rows, which is enough to make an animal blink.
    return [changes.get(index, row) for index, row in enumerate(rows)]


FOX = [
    "..K..........K..",
    ".KOK........KOK.",
    ".KOOK......KOOK.",
    ".KOBOKKKKKKOBOK.",
    ".KOOOOOOOOOOOOK.",
    "KOOOOOOOOOOOOOOK",
    "KOOBBOOOOOOBBOOK",
    "KWWOOOOOOOOOOWWK",
    ".KWWWWWBBWWWWWK.",
    "..KKWWWWWWWWKK..",
    "...KOOWWWWOOK...",
    "...KOOWWWWOOKKK.",
    "...KOOOOOOOOKOOK",
    "...KOKKOOKKOKOWK",
    "...KKK.KK.KKKKK.",
]
RABBIT = [
    "..KK......KK..",
    ".KLLK....KLLK.",
    ".KLPK....KPLK.",
    ".KLPK....KPLK.",
    ".KLPK....KPLK.",
    ".KLLKKKKKKLLK.",
    "KLLLLLLLLLLLLK",
    "KLLBBLLLLBBLLK",
    "KPPLLLPPLLLPPK",
    ".KLLLLKKLLLLK.",
    "..KKLLLLLLKK..",
    "..KLLWWWWLLK..",
    "..KLLWWWWLLKKK",
    "..KLKLLLLKLKWK",
    "..KKK.KK.KKKK.",
]
HEDGEHOG = [
    "...K..K..K..K.....",
    "..KDKKDKKDKKDK....",
    ".KDDtDDtDDtDDDK...",
    "KDtDDtDDtDDtDDDK..",
    "KDDtDDtDDtDDKKKK..",
    "KDtDDtDDtDKTTTTTK.",
    "KDDtDDtDDKTTBBTTTK",
    "KDtDDtDDKTTTTTTTBK",
    ".KDDDDDKTTPTTTTTK.",
    "..KTTKKKKTTKKKKK..",
    "..KKK....KKK......",
]
FROG = [
    "...KKK....KKK...",
    "..KWWWK..KWWWK..",
    "..KWBBK..KBBWK..",
    ".KEEEEKKKKEEEEK.",
    "KEEEEEEEEEEEEEEK",
    "KPPEEEEEEEEEEPPK",
    "KEEKEEEEEEEEKEEK",
    "KEEEKKKKKKKKEEEK",
    ".KEEEeeeeeeEEEK.",
    "KeeKEEEKKEEEKeeK",
    "KKKKKKK..KKKKKKK",
]
SQUIRREL = [
    "...........KKKK.",
    "..K..K....KtttTK",
    ".KtKKtK..KtttttK",
    ".KttttK..KttKKtK",
    "KtBBttK..KtK.KtK",
    "KtttttK..KKK.KtK",
    "KPTTtK......KttK",
    ".KKTttKKKKKKttK.",
    "..KTTttttttttK..",
    "..KTTTttttttK...",
    "..KTKTTtttttK...",
    "..KKKTTtKKttK...",
    "....KKKK.KKKK...",
]
DUCKLING = [
    "....KKKKKK....",
    "...KYYYYYYK...",
    "..KYYYYYYYYK..",
    "..KYBBYYBBYK..",
    "..KYYKyyKYYK..",
    "..KPYYyyYYPK..",
    ".KYYYYYYYYYYK.",
    "KYYKYYYYYYKYYK",
    "KYK.KYYYYK.KYK",
    ".K..KYYYYK..K.",
    "....KKKKKK....",
    "....yyK.yyK...",
    "...yyyK.yyyK..",
]
BAT = [
    "....K....K....",
    "....K....K....",
    "...KVVVVVVK...",
    "..KVvVVVVvVK..",
    ".KVvVVVVVVvVK.",
    "KVvVVVVVVVVvVK",
    "KVvVVVVVVVVvVK",
    "KVvVVVVVVVVvVK",
    ".KVvVVVVVVvVK.",
    "..KKVVVVVVKK..",
    "...KWBWWBWK...",
    "...KWWPPWWK...",
    "..KVKVVVVKVK..",
    "..KK.KKKK.KK..",
]
SLOTH = [
    "..KK........KK..",
    "..KtK......KtK..",
    "..KtK......KtK..",
    "..KtKKKKKKKKtK..",
    "..KttttttttttK..",
    ".KttTTTTTTTTttK.",
    ".KtTDDTTTTDDTtK.",
    ".KtTDBTTTTBDTtK.",
    ".KtTTTTKKTTTTtK.",
    ".KttTPTTTTPTttK.",
    "..KtttTTTTtttK..",
    "..KttttttttttK..",
    "...KttttttttK...",
    "....KKttttKK....",
    "......KKKK......",
]
RACCOON = [
    "..KK........KK..",
    ".KGGK......KGGK.",
    ".KGGKKKKKKKKGGK.",
    "KGGGGGGGGGGGGGGK",
    "KGKKKKGGGGKKKKGK",
    "KKKBWKKGGKKWBKKK",
    "KGKKKKWWWWKKKKGK",
    ".KGGWWWBBWWWGGK.",
    "..KKKWWWWWWKKK..",
    "...KGGGGGGGGK...",
    "...KGGLLLLGGKKK.",
    "...KGKGGGGKGKDGK",
    "...KKK.KK.KKKKK.",
]
BADGER = [
    "...KK......KK...",
    "..KWWKKKKKKWWK..",
    ".KWWKKWWWWKKWWK.",
    ".KWKKKWWWWKKKWK.",
    "KWWKWKWWWWKWKWWK",
    "KWWKKKWWWWKKKWWK",
    ".KWWWWWBBWWWWWK.",
    "..KKWWWWWWWWKK..",
    "..KGGGGGGGGGGK..",
    "..KGGGGGGGGGGK..",
    "..KGKKGGGGKKGK..",
    "..KKK.KKKK.KKK..",
]
TORTOISE = [
    "......KKKKKK........",
    "....KKEeEEeEKK......",
    "...KeEEKEEKEEeK.....",
    "..KEEeEEKKEEeEEK.KK.",
    ".KeEEKEEeEEKEEeEKTTK",
    ".KEeEEKKEEKKEEeEKTBK",
    "KEEEEEEEEEEEEEEEETTK",
    "KKKKKKKKKKKKKKKKKTK.",
    ".KTTK.......KTTK.K..",
    ".KKKK.......KKKK....",
]
CAPYBARA = [
    "..............KK....",
    "....KKKKKKKKKKttK...",
    "...KTTTTTTTTTTTTTK..",
    "..KTTTTTTTTTTTTBBTK.",
    "..KTTTTTTTTTTTTBBTTK",
    "..KtTTTTTTTTTTTTTTDK",
    "..KttTTTTTTTTTTTTTDK",
    "...KtttttttTTTTTTKK.",
    "...KttKKKKKKKKttK...",
    "...KtK........KtK...",
    "...KKK........KKK...",
]
RED_PANDA = [
    "..KK........KK..",
    ".KWWK......KWWK.",
    ".KOoKKKKKKKKoOK.",
    "KooooooooooooooK",
    "KoWWooooooooWWoK",
    "KWBBWooooooWBBWK",
    "KWWWWWWBBWWWWWWK",
    ".KWWWWWWWWWWWWK.",
    "..KKooooooooKK..",
    "...KDDooooDDKKK.",
    "...KDDooooDDoWK.",
    "...KDKDDDDKDKoWK",
    "...KKK.KK.KKKKK.",
]
MOLE = [
    "....KKKKKK....",
    "...KDDDDDDK...",
    "..KDDDDDDDDK..",
    "..KDBDDDDBDK..",
    ".KDDDDPPDDDDK.",
    ".KDDDKPPKDDDK.",
    "KDDDDDDDDDDDDK",
    "KWWKDDDDDDKWWK",
    "KWWKDDDDDDKWWK",
    "KKKKKKKKKKKKKK",
]
MONKEY = [
    "...KtK....KtK...",
    "...KtK....KtK...",
    "...KtK....KtK...",
    "...KttKKKKttK...",
    "...KttttttttK...",
    "..KKttttttttKK..",
    ".KTtKtTTTTtKtTK.",
    ".KTtKTBTTBTKtTK.",
    "..KKTTTTTTTTKK..",
    "...KTTKKKKTTK...",
    "...KTTTPPTTTK...",
    "....KtttttK.....",
    "...KttttttK.KK..",
    "...KttKKttKKtK..",
    "...KKK..KKK.KK..",
]
OPOSSUM = [
    "......KK......",
    "......KPK.....",
    "......KPK.....",
    ".....KGGK.....",
    "....KGGGGK....",
    "...KGGGGGGK...",
    "..KGGGGGGGGK..",
    "..KGGLGGLGGK..",
    "..KGGGGGGGGK..",
    "...KGGGGGGK...",
    "..KPKLLLLKPK..",
    "..KPLLLLLLPK..",
    "...KLBLLBLK...",
    "...KLLLLLLK...",
    "....KLPPLK....",
    ".....KKKK.....",
]
HANGING_PARROT = [
    "...K....K...",
    "...K....K...",
    "..KRRRRRRK..",
    "..KRRRRRRK..",
    ".KEEEEEEEEK.",
    ".KEeEEEEeEK.",
    ".KEeEEEEeEK.",
    ".KEEEEEEEEK.",
    ".KeEEEEEEeK.",
    "..KEEEEEEK..",
    "..KEBEEBEK..",
    "..KEEEEEEK..",
    "...KEyyEK...",
    "....KyyK....",
    ".....KK.....",
]
RUNNING_FOX = [
    "................K..K..",
    "...............KOKKOK.",
    "KKK............KOOOOOK",
    "KWOKKKKKKKKKKKKOOBOOOB",
    "KWOOOOOOOOOOOOOOOOOWWK",
    ".KKOOOOOOOOOOOOOOWWKK.",
    "...KOOOOOOOOOOOOWKK...",
    "...KOOKOOOOOOKOOK.....",
    "..KOKK.KOK.KOK.KOK....",
    "..KK....KK..KK..KK....",
]
RUNNING_FOX_LEGS = {
    8: "....KOK..KOKOK..KOK...",
    9: "....KK....KKK....KK...",
}
DEER = [
    "..................K..K..",
    "..................KK.K..",
    "...................KKK..",
    "..................KttK.K",
    "..................KtttKK",
    "..................KtBttK",
    "..................KttWWK",
    ".KK...............KtttK.",
    "KWWKKKKKKKKKKKKKKKtttK..",
    "KWtttttttttttttttttttK..",
    ".KtWtttWtttWtttttttttK..",
    ".KtttWtttWtttttttttWWK..",
    ".KttttttttttttttttWWK...",
    ".KtttKKKKKKKKKKKtttK....",
    "..KtK..........KtK......",
    "..KtK..........KtK......",
    "..KtK..........KtK......",
    "..KKK..........KKK......",
]
BIRD = [
    "..KK.....KK..",
    ".KRRK...KRRK.",
    "..KRRK.KRRK..",
    "...KRRKRRK.K.",
    "....KRRRKKYK.",
    ".....KKK..K..",
]
BIRD_WINGS_DOWN = [
    ".............",
    ".............",
    "...KKK...K...",
    "..KRRRKKKYK..",
    ".KRRRRRRK.K..",
    "KRRK.KRRK....",
]
BUTTERFLY = [
    "KK.K.KK",
    "KsK.KsK",
    "KssKssK",
    ".KsKsK.",
    "KsKKKsK",
    "KK...KK",
]
BUTTERFLY_FOLDED = [
    "...K...",
    "..KsK..",
    ".KssK..",
    "..KsK..",
    ".KsKK..",
    ".KK....",
]

SPRITES = {
    "fox": [FOX, changed_rows(FOX, {6: "KOOKKOOOOOOKKOOK"})],
    "rabbit": [RABBIT, changed_rows(RABBIT, {7: "KLLKKLLLLKKLLK"})],
    "hedgehog": [HEDGEHOG, changed_rows(HEDGEHOG, {6: "KDDtDDtDDKTTKKTTTK"})],
    "frog": [FROG, changed_rows(FROG, {2: "..KKKKK..KKKKK.."})],
    "squirrel": [SQUIRREL, changed_rows(SQUIRREL, {4: "KtKKttK..KtK.KtK"})],
    "duckling": [DUCKLING, changed_rows(DUCKLING, {3: "..KYKKYYKKYK.."})],
    "bat": [BAT, changed_rows(BAT, {10: "...KWKWWKWK..."})],
    "sloth": [SLOTH, changed_rows(SLOTH, {7: ".KtTDDTTTTDDTtK."})],
    "raccoon": [RACCOON, changed_rows(RACCOON, {5: "KKKKKKKGGKKKKKKK"})],
    "badger": [BADGER, changed_rows(BADGER, {4: "KWWKKKWWWWKKKWWK"})],
    "tortoise": [TORTOISE, changed_rows(TORTOISE, {5: ".KEeEEKKEEKKEEeEKTKK"})],
    "capybara": [CAPYBARA, changed_rows(CAPYBARA, {3: "..KTTTTTTTTTTTTTTTK.", 4: "..KTTTTTTTTTTTTKKTTK"})],
    "red_panda": [RED_PANDA, changed_rows(RED_PANDA, {5: "KWKKWooooooWKKWK"})],
    "mole": [MOLE, changed_rows(MOLE, {3: "..KDKDDDDKDK.."})],
    "monkey": [MONKEY, changed_rows(MONKEY, {7: ".KTtKTKTTKTKtTK."})],
    "opossum": [OPOSSUM, changed_rows(OPOSSUM, {12: "...KLKLLKLK..."})],
    "hanging_parrot": [HANGING_PARROT, changed_rows(HANGING_PARROT, {10: "..KEKEEKEK.."})],
    "running_fox": [RUNNING_FOX, changed_rows(RUNNING_FOX, RUNNING_FOX_LEGS)],
    "deer": [DEER],
    "bird": [BIRD, BIRD_WINGS_DOWN],
    "butterfly": [BUTTERFLY, BUTTERFLY_FOLDED],
}
# Animals that walk or burrow stand on the ground blocks below the opening.
GROUND_CREATURES = ("fox", "rabbit", "hedgehog", "frog", "squirrel", "duckling",
                    "raccoon", "badger", "tortoise", "capybara", "red_panda", "mole")
# Animals that really do hang from branches appear under the blocks above it.
HANGING_CREATURES = ("bat", "sloth", "monkey", "opossum", "hanging_parrot")
# The next animal arrives after this many obstacle pairs: about every second pair.
fewest_obstacles_between_animals = 1
most_obstacles_between_animals = 3
hanging_animal_chance = 0.35
# A private generator, so animals never change where the openings are placed.
creature_random = random.Random()
waiting_ground_creatures = []
waiting_hanging_creatures = []
obstacles_until_animal = 0
creature_scale = 3
creature_hide_distance = 70  # Animals start ducking when the plane is this close.


@lru_cache(maxsize=128)
def get_sprite(name, frame=0, scale=creature_scale, tint=None):
    rows = SPRITES[name][frame]
    # enumerate gives each row's number, which is the pixel's y position.
    picture = pygame.Surface((len(rows[0]), len(rows)), pygame.SRCALPHA)
    for y, row in enumerate(rows):
        for x, letter in enumerate(row):
            if letter != ".":
                picture.set_at((x, y), SPRITE_COLORS[letter])
    if tint is not None:
        picture.fill((*tint, 255), special_flags=pygame.BLEND_RGBA_MULT)
    return pygame.transform.scale(picture, (picture.get_width() * scale,
                                            picture.get_height() * scale))


def get_blink_frame(animal_id):
    # Most of the time the eyes are open; each animal blinks at its own moment.
    return 1 if (ambient_frames + animal_id * 37) % 170 < 9 else 0


def lerp_color(start, end, amount):
    return tuple(round(a + (b - a) * amount) for a, b in zip(start, end))


sky_body_center = (600, 170)  # Where the sun and moon sit in the sky.


def make_sky(theme, seed):
    # Wide color bands look like a limited retro palette instead of a smooth photo.
    sky = pygame.Surface((WIDTH, HEIGHT)).convert()
    top, middle, bottom = theme["sky"]
    band = 20
    for y in range(0, HEIGHT, band):
        amount = y / HEIGHT
        color = (lerp_color(top, middle, amount * 2) if amount < 0.5
                 else lerp_color(middle, bottom, amount * 2 - 1))
        pygame.draw.rect(sky, color, (0, y, WIDTH, band))

    # A private generator keeps the scenery from changing the game's random obstacles.
    generator = random.Random(seed)
    for _ in range(theme["stars"]):
        size = generator.choice((2, 2, 4))
        position = (generator.randrange(WIDTH), generator.randrange(360))
        pygame.draw.rect(sky, (255, 244, 200), (*position, size, size))
    return sky


def make_sun_or_moon(theme, sky):
    # Kept apart from the sky so the sun and moon are never see-through on top of each other.
    picture = pygame.Surface((176, 176), pygame.SRCALPHA)
    middle = (88, 88)
    if theme["stars"]:
        # Drawing a see-through circle over the full moon carves it into a crescent.
        pygame.draw.circle(picture, theme["body"], middle, 72)
        pygame.draw.circle(picture, (0, 0, 0, 0), (122, 74), 62)
    else:
        # A soft ring around the sun: halfway between the sun and the sky color.
        halo = lerp_color(theme["body"], sky.get_at(sky_body_center), 0.55)
        pygame.draw.circle(picture, halo, middle, 88)
        pygame.draw.circle(picture, theme["body"], middle, 70)
    return picture


def make_clouds(color, seed):
    layer = pygame.Surface((WIDTH, 300), pygame.SRCALPHA)
    generator = random.Random(seed)
    for x in range(30, WIDTH - 170, 190):
        y = generator.randrange(20, 250)
        step = generator.choice((8, 10, 12))
        pygame.draw.rect(layer, color, (x, y + step * 2, step * 13, step * 2))
        pygame.draw.rect(layer, color, (x + step * 2, y + step, step * 9, step))
        pygame.draw.rect(layer, color, (x + step * 4, y, step * 4, step))
    return layer


def wavy_height(x, base, waves):
    # Whole numbers of waves across the width make the two ends join seamlessly.
    return base + sum(size * math.sin(math.tau * count * x / WIDTH + phase)
                      for count, size, phase in waves)


def make_mountains(color, snow_color, seed):
    height = 260
    layer = pygame.Surface((WIDTH, height), pygame.SRCALPHA)
    generator = random.Random(seed)
    waves = [(count, generator.uniform(14, 44) / count ** 0.5, generator.uniform(0, math.tau))
             for count in (2, 3, 5, 9)]
    step = 8  # Wide steps keep the slopes blocky, like pixel art.
    for x in range(0, WIDTH, step):
        top = round(wavy_height(x, 110, waves) / step) * step
        pygame.draw.rect(layer, color, (x, top, step, height - top))
        if top < 92:  # Only the highest peaks are tall enough to keep their snow.
            pygame.draw.rect(layer, snow_color, (x, top, step, min(32, 92 - top + 8)))
    return layer


def draw_round_tree(layer, x, base, color, seed):
    # Three overlapping blocks make a leafy crown on a short trunk.
    size = random.Random(seed).randrange(14, 24, 2)
    pygame.draw.rect(layer, lerp_color(color, INK, 0.4), (x - 3, base - 26, 6, 28))
    pygame.draw.rect(layer, color, (x - size, base - 26 - size, size * 2, size))
    pygame.draw.rect(layer, color, (x - size + 6, base - 32 - size, size * 2 - 12, 6))
    pygame.draw.rect(layer, color, (x - size - 4, base - 20 - size, size * 2 + 8, size // 2 + 2))


def make_forest(hill_color, tree_color, tint, seed):
    height = 260
    layer = pygame.Surface((WIDTH, height), pygame.SRCALPHA)
    generator = random.Random(seed)
    waves = [(1, 14, generator.uniform(0, math.tau)), (3, 8, generator.uniform(0, math.tau))]
    step = 8
    hill_top = {}
    for x in range(0, WIDTH, step):
        hill_top[x] = round(wavy_height(x, 110, waves) / step) * step

    x = 0
    while x < WIDTH:
        tree_height = generator.randrange(40, 80, 8)
        base = hill_top[x // step * step] + 8
        for draw_x in (x, x - WIDTH):  # A tree crossing the edge also appears on the other side.
            pygame.draw.rect(layer, lerp_color(tree_color, INK, 0.3),
                             (draw_x - 3, base - 12, 6, 20))
            # Rows of shrinking blocks make a stepped pine tree.
            for row in range(0, tree_height, 8):
                half_width = 4 + row // 3
                top = base - tree_height + row - 8
                pygame.draw.rect(layer, tree_color, (draw_x - half_width, top, half_width * 2, 8))
        x += generator.randrange(32, 92, 4)

    for x in range(40, WIDTH - 40, 170):
        draw_round_tree(layer, x, hill_top[x // step * step] + 8,
                        lerp_color(tree_color, hill_color, 0.45), seed + x)

    for x, top in hill_top.items():
        pygame.draw.rect(layer, hill_color, (x, top, step, height - top))

    # Bushes, flowers and two grazing deer sit on the hill and scroll along with it.
    bush = lerp_color(hill_color, tree_color, 0.7)
    light = lerp_color(hill_color, CREAM, 0.25)
    for _ in range(9):
        x = generator.randrange(24, WIDTH - 60, step)
        top = hill_top[x]
        pygame.draw.rect(layer, bush, (x, top - 8, 40, 12))
        pygame.draw.rect(layer, bush, (x + 8, top - 16, 22, 10))
    for _ in range(46):
        x = generator.randrange(0, WIDTH - 8, 4)
        y = hill_top[x // step * step] + generator.randrange(10, 66, 4)
        color = generator.choice((light, light, CREAM, SUN, (240, 130, 150)))
        if tint is not None:
            color = lerp_color(color, hill_color, 0.55)
        pygame.draw.rect(layer, color, (x, y, 4, 4))
    for x in (216, 608):
        deer = get_sprite("deer", 0, 2, tint)
        layer.blit(deer, (x, hill_top[x] - deer.get_height() + 10))
    return layer


def make_foreground(color, seed):
    # A strip of grass, flowers, mushrooms and pebbles in front of everything.
    height = 30
    layer = pygame.Surface((WIDTH, height), pygame.SRCALPHA)
    generator = random.Random(seed)
    pygame.draw.rect(layer, color, (0, height - 8, WIDTH, 8))
    for x in range(0, WIDTH, 4):
        blade = generator.choice((4, 8, 8, 12))
        pygame.draw.rect(layer, color, (x, height - 8 - blade, 4, blade))
    for x in range(30, WIDTH - 30, 96):
        kind = generator.choice(("flower", "flower", "mushroom", "pebble"))
        if kind == "flower":
            petal = generator.choice(((240, 130, 150), SUN, CREAM, (190, 150, 240)))
            pygame.draw.rect(layer, lerp_color(color, INK, 0.25), (x + 4, height - 18, 4, 14))
            pygame.draw.rect(layer, petal, (x, height - 26, 12, 12))
            pygame.draw.rect(layer, (255, 226, 112), (x + 4, height - 22, 4, 4))
        elif kind == "mushroom":
            pygame.draw.rect(layer, CREAM, (x + 4, height - 14, 6, 10))
            pygame.draw.rect(layer, RED, (x, height - 22, 14, 8))
            pygame.draw.rect(layer, CREAM, (x + 3, height - 20, 3, 3))
        else:
            pygame.draw.rect(layer, (150, 148, 136), (x, height - 12, 16, 8))
            pygame.draw.rect(layer, (190, 188, 172), (x + 2, height - 12, 8, 3))
    return layer


scenery = [{
    "sky": make_sky(theme, index),
    # Every sky shares one cloud shape, so a change of sky only changes their color.
    "clouds": make_clouds(theme["cloud"], 10),
    "far": make_mountains(theme["far"], theme["snow"], index + 20),
    "near": make_forest(theme["near"], theme["tree"], theme["tint"], index + 30),
    "foreground": make_foreground(theme["ground"], index + 40),
} for index, theme in enumerate(SKY_THEMES)]
for theme, scene in zip(SKY_THEMES, scenery):
    scene["body"] = make_sun_or_moon(theme, scene["sky"])
    # These layers are only solid or empty pixels; RLEACCEL skips the empty ones quickly.
    for name in ("clouds", "far", "near", "foreground"):
        scene[name].set_alpha(255, pygame.RLEACCEL)

def get_plane_sprite(shake=False):
    # Pop the head above the cockpit, keeping the chin tucked behind the sill.
    angle = 0
    if shake:
        angle = head_sway_angle * math.sin(
            pygame.time.get_ticks() / 1000 * math.tau * head_sway_speed
        )
    head = pygame.transform.rotate(pilot_head, angle)
    head_center = pygame.Vector2(103, 95) + pygame.Vector2(
        0, -pilot_head.get_height() / 2
    ).rotate(-angle)
    sprite = pygame.Surface((192, 192), pygame.SRCALPHA)
    sprite.blit(bird_image, bird_image.get_rect(center=(96, 96)))
    sprite.set_clip(pygame.Rect(0, 0, 192, 93))
    sprite.blit(head, head.get_rect(center=(round(head_center.x), round(head_center.y))))
    sprite.set_clip(None)
    return sprite


@lru_cache(maxsize=128)
def get_obstacle_image(width, height, ceiling=False):
    # Keep every pixel inside the original obstacle rectangle.
    # This private generator gives each height its own stable pattern of details.
    generator = random.Random(height * 2 + ceiling)
    obstacle = pygame.Surface((width, height)).convert()
    obstacle.fill(INK)

    # Wavy layers of soil, from dark topsoil to warmer earth, instead of a block grid.
    layers = ((122, 80, 52), (142, 94, 58), (160, 108, 66), (134, 88, 60))
    step = 8
    offsets = [generator.randrange(-8, 9, 4) for _ in range(0, width, step)]
    for column, x in enumerate(range(0, width, step)):
        y = 0
        band = 0
        while y < height:
            thickness = 46 + (band * 17 % 24) + offsets[column]
            pygame.draw.rect(obstacle, layers[band % len(layers)], (x, y, step, thickness))
            y += thickness
            band += 1
    pygame.draw.rect(obstacle, INK, (0, 0, 4, height))
    pygame.draw.rect(obstacle, INK, (width - 4, 0, 4, height))
    pygame.draw.rect(obstacle, (182, 134, 88), (4, 0, 4, height))
    pygame.draw.rect(obstacle, (96, 62, 42), (width - 12, 0, 8, height))

    # Pebbles, roots and little buried surprises.
    for y in range(36, height - 12, 26):
        x = generator.randrange(12, width - 26)
        detail = generator.choice(("pebble", "pebble", "dark", "root"))
        if detail == "pebble":
            pygame.draw.rect(obstacle, (170, 164, 148), (x, y, 12, 8))
            pygame.draw.rect(obstacle, (206, 200, 182), (x + 2, y, 6, 3))
        elif detail == "dark":
            pygame.draw.rect(obstacle, (98, 64, 44), (x, y, 8, 4))
        else:
            pygame.draw.rect(obstacle, (206, 170, 120), (x, y, 3, 12))
            pygame.draw.rect(obstacle, (206, 170, 120), (x + 3, y + 8, 7, 3))
    if height > 130:
        x = generator.randrange(14, width - 34)
        y = generator.randrange(60, height - 30)
        if generator.random() < 0.5:  # A buried bone.
            pygame.draw.rect(obstacle, CREAM, (x + 3, y + 3, 14, 4))
            for end_x, end_y in ((x, y), (x, y + 6), (x + 16, y), (x + 16, y + 6)):
                pygame.draw.rect(obstacle, CREAM, (end_x, end_y, 4, 4))
        else:  # A buried acorn.
            pygame.draw.rect(obstacle, (196, 130, 62), (x + 2, y + 4, 10, 9))
            pygame.draw.rect(obstacle, (98, 64, 44), (x, y, 14, 5))

    # Grass on the ground blocks, darker moss under the hanging ones.
    grass, highlight = (LEAF, (128, 196, 92)) if not ceiling else (FOREST, LEAF)
    pygame.draw.rect(obstacle, INK, (0, 0, width, 22))
    pygame.draw.rect(obstacle, grass, (0, 4, width, 14))
    pygame.draw.rect(obstacle, highlight, (0, 4, width, 4))
    for x in range(0, width, 10):
        drip = generator.choice((4, 8, 12, 16 if ceiling else 8))
        pygame.draw.rect(obstacle, INK, (x, 18, 10, drip + 4))
        pygame.draw.rect(obstacle, grass, (x + 2, 18, 6, drip))
    for x in range(8, width - 8, 16):
        if generator.random() < 0.55:
            color = generator.choice((CREAM, SUN, (240, 130, 150)))
            pygame.draw.rect(obstacle, color, (x, 8, 4, 4))

    if ceiling:
        obstacle = pygame.transform.flip(obstacle, False, True)
    return obstacle


def get_creature_hide_amount(rect):
    # 0 means fully visible and 1 means fully tucked behind the soil block.
    clearance = max(rect.left - (bird_x + 50), (bird_x - 50) - rect.right, 0)
    return max(0.0, 1 - clearance / creature_hide_distance)


def draw_creatures():
    for top_pipe, bottom_pipe in pipes:
        if bottom_pipe.creature is not None:
            sprite = get_sprite(bottom_pipe.creature, get_blink_frame(bottom_pipe.height))
            # A small two-step bounce makes the animals look as if they are breathing.
            breath = 3 if (ambient_frames + bottom_pipe.height * 11) % 60 < 30 else 0
            visible = (sprite.get_height() + 4) * (1 - get_creature_hide_amount(bottom_pipe))
            screen.blit(sprite, sprite.get_rect(
                midbottom=(bottom_pipe.centerx,
                           bottom_pipe.top + 5 - round(visible) + sprite.get_height() + breath)
            ))
        if top_pipe.creature is not None:
            sprite = get_sprite(top_pipe.creature, get_blink_frame(top_pipe.height))
            visible = sprite.get_height() * (1 - get_creature_hide_amount(top_pipe))
            screen.blit(sprite, sprite.get_rect(
                midtop=(top_pipe.centerx, top_pipe.bottom - 6 + round(visible) - sprite.get_height())
            ))


@lru_cache(maxsize=64)
def get_silhouette(pet, on_pillar=False):
    # The cutouts are already transparent: keep the shape and paint it all dark.
    picture = (character_heads if on_pillar else character_portraits)[pet].copy()
    picture.fill((0, 0, 0, 255), special_flags=pygame.BLEND_RGBA_MULT)
    picture.fill((*INK, 0), special_flags=pygame.BLEND_RGBA_ADD)
    return picture


def draw_waiting_dogs():
    for _, bottom_pipe in pipes:
        if bottom_pipe.dog is None:
            continue
        # Unlike the wild animals, a new friend stays in sight and waits to be picked up.
        hop = 3 if (ambient_frames + bottom_pipe.height * 11) % 40 < 20 else 0
        picture = get_silhouette(bottom_pipe.dog, on_pillar=True)
        rect = picture.get_rect(midbottom=(bottom_pipe.centerx, bottom_pipe.top + 4 - hop))
        screen.blit(picture, rect)
        draw_text("？？？", 2, (rect.centerx, rect.top - 14), SUN, INK)


def get_difficulty(current_score):
    gap = max(minimum_pipe_gap, round(starting_pipe_gap - current_score * gap_reduction_per_point))
    speed = min(maximum_pipe_speed, starting_pipe_speed + current_score * speed_increase_per_point)
    shift_margin = min(
        maximum_shift_margin,
        starting_shift_margin + current_score * shift_margin_increase_per_point,
    )
    return gap, speed, shift_margin


def move_pipes(current_score):
    global pipe_scroll_remainder
    speed = get_difficulty(current_score)[1]
    # Rect positions are integers: carry fractional movement into the next frame.
    pipe_scroll_remainder += speed
    movement = int(pipe_scroll_remainder)
    pipe_scroll_remainder -= movement
    for top_pipe, bottom_pipe in pipes:
        top_pipe.x -= movement
        bottom_pipe.x -= movement


class Obstacle(pygame.Rect):
    # This is still a normal Rect for movement and collisions; it can also remember
    # which animal lives on it. None means this obstacle has no animal.
    creature = None
    dog = None  # The locked pet waiting on this block, if there is one.


def get_gap_center(pipe_pair):
    top_pipe, bottom_pipe = pipe_pair
    return (top_pipe.bottom + bottom_pipe.top) // 2


def get_fall_distance(frames):
    # A fall starts slowly: it speeds up until it reaches the maximum fall speed.
    frames_to_top_speed = maximum_fall_speed / gravity
    if frames <= frames_to_top_speed:
        return gravity * frames * frames / 2
    speeding_up = gravity * frames_to_top_speed * frames_to_top_speed / 2
    return speeding_up + maximum_fall_speed * (frames - frames_to_top_speed)


def get_maximum_gap_shift(pipe_gap, speed, shift_margin):
    # The plane may use the room inside the opening, plus the height it can drop
    # while flying through the clear space between two obstacles.
    room_in_gap = pipe_gap - bird_radius * 2
    clear_frames = (pipe_spacing - pipe_width - bird_radius * 2) / speed
    return shift_margin * (room_in_gap + get_fall_distance(clear_frames))


def create_pipe(current_score=0, previous_gap_y=None):
    # Only new obstacles use the narrower gap; visible openings stay unchanged.
    pipe_gap, speed, shift_margin = get_difficulty(current_score)
    lowest_gap_y = max(150, pipe_gap // 2 + 40)
    highest_gap_y = min(450, HEIGHT - (pipe_gap - pipe_gap // 2) - 40)
    if previous_gap_y is not None:
        # Never place an opening farther away than the plane can reach in time.
        shift = int(get_maximum_gap_shift(pipe_gap, speed, shift_margin))
        lowest_gap_y = max(lowest_gap_y, previous_gap_y - shift)
        highest_gap_y = min(highest_gap_y, previous_gap_y + shift)
    gap_y = random.randint(lowest_gap_y, highest_gap_y)
    gap_top = gap_y - pipe_gap // 2
    gap_bottom = gap_top + pipe_gap

    top_pipe = Obstacle(
        WIDTH,
        0,
        pipe_width,
        gap_top
    )

    bottom_pipe = Obstacle(
        WIDTH,
        gap_bottom,
        pipe_width,
        HEIGHT - gap_bottom
    )

    return [top_pipe, bottom_pipe]


def choose_next_animal_delay():
    return creature_random.randint(fewest_obstacles_between_animals,
                                   most_obstacles_between_animals)


def take_next_creature(waiting, all_creatures):
    # Like drawing from a shuffled deck: every species appears before any repeats.
    if not waiting:
        waiting.extend(creature_random.sample(all_creatures, len(all_creatures)))
    return waiting.pop()


def assign_creature(pipe_pair):
    global obstacles_until_animal
    obstacles_until_animal -= 1
    if obstacles_until_animal > 0:
        return
    obstacles_until_animal = choose_next_animal_delay()
    top_pipe, bottom_pipe = pipe_pair
    if creature_random.random() < hanging_animal_chance:
        top_pipe.creature = take_next_creature(waiting_hanging_creatures, HANGING_CREATURES)
    else:
        bottom_pipe.creature = take_next_creature(waiting_ground_creatures, GROUND_CREATURES)


def count_found_dogs():
    return len(unlocked_pets) - len(STARTER_PETS)


def get_pillars_needed():
    # The first dogs come quickly; after that, finding one takes some flying.
    found = count_found_dogs()
    if found < len(pillars_for_first_dogs):
        return pillars_for_first_dogs[found]
    return get_gap_between_dogs(len(PETS) - len(STARTER_PETS))


def get_gap_between_dogs(pets_to_find):
    gap = pillars_for_whole_album // max(1, pets_to_find)
    return max(fewest_pillars_between_dogs, min(most_pillars_between_dogs, gap))


def choose_next_dog(locked):
    # The list follows the data file, so its last pet is the most recently added one.
    if random.random() < recent_pet_chance:
        return locked[-1]
    return random.choice(locked)


def assign_dog(pipe_pair):
    # Returns True when this obstacle pair now carries the next locked dog.
    global next_dog
    locked = [index for index in range(len(PETS)) if index not in unlocked_pets]
    dog_on_screen = any(bottom_pipe.dog is not None for _, bottom_pipe in pipes)
    if not locked or dog_on_screen or pillars_since_dog < get_pillars_needed():
        return False
    if next_dog not in locked:
        next_dog = choose_next_dog(locked)
    pipe_pair[1].dog = next_dog
    return True


def get_pillars_left():
    # How many more pillars until the next new friend; None once everyone is found.
    if len(unlocked_pets) >= len(PETS):
        return None
    return max(0, get_pillars_needed() - pillars_since_dog)


def start_celebration():
    global celebration_frames
    celebration_frames = celebration_duration
    confetti_pieces.clear()
    for number in range(70):
        angle = math.tau * number / 70
        speed = random.uniform(2, 8)
        confetti_pieces.append({
            "x": bird_x, "y": bird_y,
            "vx": math.cos(angle) * speed, "vy": math.sin(angle) * speed - 2,
            "size": random.randint(4, 9), "color": random.choice(CONFETTI_COLORS),
        })


def update_celebration():
    global celebration_frames
    celebration_frames = max(0, celebration_frames - 1)
    for piece in confetti_pieces:
        piece["x"] += piece["vx"]
        piece["y"] += piece["vy"]
        piece["vy"] += 0.18
    confetti_pieces[:] = [piece for piece in confetti_pieces if piece["y"] < HEIGHT]


def collect_passed_dogs():
    global pillars_since_dog, dog_message_frames, newest_dog
    for _, bottom_pipe in pipes:
        if bottom_pipe.dog is not None and bottom_pipe.right < bird_x - bird_radius:
            unlocked_pets.add(bottom_pipe.dog)
            newly_found_dogs.append(bottom_pipe.dog)
            track("pet_found", pet=PETS[bottom_pipe.dog]["id"], score=score)
            newest_dog = bottom_pipe.dog
            start_celebration()
            bottom_pipe.dog = None
            pillars_since_dog = 0
            dog_message_frames = dog_message_duration
            save_progress()


def read_saved_progress():
    if IS_WEB:
        saved = platform.window.localStorage.getItem(WEB_PROGRESS_KEY)
    else:
        saved = PROGRESS_FILE.read_text(encoding="utf-8") if PROGRESS_FILE.exists() else None
    return json.loads(str(saved)) if saved else {}


def save_progress():
    # Ids, not list positions: removing one pet later must not shift everyone else's.
    progress = json.dumps({
        "unlocked": [PETS[index]["id"] for index in sorted(unlocked_pets)],
        "pillars": pillars_since_dog,
        "selected": PETS[selected_character]["id"],
    })
    try:
        if IS_WEB:
            platform.window.localStorage.setItem(WEB_PROGRESS_KEY, progress)
        else:
            PROGRESS_FILE.parent.mkdir(parents=True, exist_ok=True)
            PROGRESS_FILE.write_text(progress, encoding="utf-8")
    except STORAGE_ERRORS:
        pass  # The game still works; this visit's dogs just will not be remembered.


def load_progress():
    global pillars_since_dog
    try:
        saved = read_saved_progress()
    except (*STORAGE_ERRORS, ValueError):
        saved = {}
    if not isinstance(saved, dict):
        saved = {}
    # .get() returns the fallback when a saved value is missing, and ids of
    # pets that no longer exist are simply skipped.
    for pet_id in saved.get("unlocked", []):
        if pet_id in PET_INDEX_BY_ID:
            unlocked_pets.add(PET_INDEX_BY_ID[pet_id])
    pillars = saved.get("pillars", 0)
    pillars_since_dog = pillars if isinstance(pillars, int) else 0
    selected = PET_INDEX_BY_ID.get(saved.get("selected"))
    if selected in unlocked_pets:
        set_pilot(selected)


def track(event, **details):
    # Only the web page reports anything, and only if an analytics key was set at build time.
    if not IS_WEB:
        return
    try:
        platform.window.flightFriendsTrack(event, json.dumps(details))
    except Exception:
        pass  # Statistics must never be able to stop the game.


def get_pilot_id():
    return PETS[selected_character]["id"]


def get_linked_pet_id():
    # A pet's own link looks like: .../flight-friends/?pet=doudou
    if not IS_WEB:
        return None
    query = str(platform.window.location.search).lstrip("?")
    return parse_qs(query).get("pet", [None])[0]


def apply_pet_link(pet_id):
    global welcome_pet, linked_pet, partner_slot_pet
    pet = PET_INDEX_BY_ID.get(pet_id)
    if pet is None:
        return False
    linked_pet = pet
    if pet not in FIXED_SLOT_PETS:
        partner_slot_pet = FIXED_SLOT_PETS[-1]  # The fixed pet pushed down to the last card.
    unlocked_pets.add(pet)
    set_pilot(pet)
    welcome_pet = pet
    save_progress()
    return True


def reset_bird():
    global bird_y, bird_velocity

    bird_y = 300
    bird_velocity = 0


def update_bird():
    global bird_y, bird_velocity
    bird_velocity = min(bird_velocity + gravity, maximum_fall_speed)
    bird_y += bird_velocity


def reset_game():
    global pipes, score, started, game_over
    global death_started_at, explosion_particles, death_image
    global new_best
    global paused, paused_plane
    global pipe_scroll_remainder
    global current_theme, previous_theme, theme_fade, flap_puffs, score_pop_frames
    global obstacles_until_animal
    global album_open, album_page, dog_message_frames, welcome_pet
    global newest_dog, celebration_frames

    reset_bird()

    pipes = []
    pipes.append(create_pipe())

    score = 0
    pipe_scroll_remainder = 0.0
    started = False
    game_over = False
    new_best = False
    paused = False
    paused_plane = None
    death_started_at = None
    explosion_particles = []
    death_image = None
    current_theme = 0
    previous_theme = None
    theme_fade = 1.0
    flap_puffs = []
    score_pop_frames = 0
    obstacles_until_animal = choose_next_animal_delay()
    album_open = False
    album_page = 0
    newly_found_dogs.clear()
    dog_message_frames = 0
    newest_dog = None
    celebration_frames = 0
    confetti_pieces.clear()
    welcome_pet = None


def on_character_screen():
    return not started and not game_over and death_started_at is None


def set_pilot(index):
    global selected_character, pilot_head, partner_slot_pet
    selected_character = index
    pilot_head = character_heads[index]
    if index not in get_slot_pets():
        partner_slot_pet = index


def select_character(index):
    if (not on_character_screen() or not 0 <= index < len(CHARACTERS)
            or index not in unlocked_pets):
        return False
    set_pilot(index)
    return True


def open_upload_form():
    track("upload_click", pet=get_pilot_id())
    if IS_WEB:
        # If the browser blocks the new tab, open the form in this tab instead.
        if not platform.window.open(UPLOAD_FORM_URL, "_blank"):
            platform.window.location.href = UPLOAD_FORM_URL
    else:
        webbrowser.open(UPLOAD_FORM_URL)


def get_slot_pets():
    if linked_pet is None:
        return [*FIXED_SLOT_PETS, partner_slot_pet]
    # The linked pet goes first and everyone else moves down one card.
    others = [pet for pet in FIXED_SLOT_PETS if pet != linked_pet]
    return [linked_pet, *others[:5], partner_slot_pet]


def use_new_dog():
    # On the crash screen, each press of C moves on to the next dog found in this run.
    if game_over and newly_found_dogs:
        position = -1
        if selected_character in newly_found_dogs:
            position = newly_found_dogs.index(selected_character)
        set_pilot(newly_found_dogs[(position + 1) % len(newly_found_dogs)])
        save_progress()


def record_run_start():
    global runs_this_visit, run_started_at
    runs_this_visit += 1
    run_started_at = pygame.time.get_ticks()
    track("game_start", pet=get_pilot_id(), run=runs_this_visit)


def flap_or_start():
    global started, game_over, bird_velocity
    if paused or (death_started_at is not None and not game_over):
        return
    if game_over:
        reset_game()
    if not started:
        record_run_start()
    started = True
    game_over = False
    bird_velocity = jump_strength
    flap_puffs.append([bird_x - 34, bird_y + 12, 0])


def get_album_page_pets():
    first = album_page * album_page_size
    return range(first, min(first + album_page_size, len(PETS)))


def choose_album_pet(position):
    global album_open
    page_pets = get_album_page_pets()
    if position < len(page_pets) and select_character(page_pets[position]):
        album_open = False


def handle_album(event):
    global album_open, album_page
    pages = (len(PETS) - 1) // album_page_size + 1
    if event.type == pygame.KEYDOWN:
        keys = [pygame.K_1 + index for index in range(album_page_size)]
        if event.key in (pygame.K_ESCAPE, pygame.K_8):
            album_open = False
        elif event.key in (pygame.K_LEFT, pygame.K_RIGHT):
            album_page = (album_page + (-1 if event.key == pygame.K_LEFT else 1)) % pages
        elif event.key in keys:
            choose_album_pet(keys.index(event.key))
        return True  # Keys belong to the album, so space cannot start a game behind it.
    if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
        if album_previous_button.collidepoint(event.pos):
            album_page = (album_page - 1) % pages
        elif album_next_button.collidepoint(event.pos):
            album_page = (album_page + 1) % pages
        elif start_button.collidepoint(event.pos):
            album_open = False
        else:
            for position, rect in enumerate(character_cards):
                if rect.collidepoint(event.pos):
                    choose_album_pet(position)
        return True
    return False


def handle_character_selection(event):
    global album_open
    if not on_character_screen():
        return False
    if album_open:
        return handle_album(event)
    slot_pets = get_slot_pets()
    if event.type == pygame.KEYDOWN:
        # Number keys have consecutive codes, so one line covers every card.
        keys = [pygame.K_1 + index for index in range(len(slot_pets))]
        if event.key in keys:
            select_character(slot_pets[keys.index(event.key)])
            return True
        if event.key == pygame.K_8:
            album_open = True
            return True
        if event.key in (pygame.K_LEFT, pygame.K_RIGHT):
            direction = -1 if event.key == pygame.K_LEFT else 1
            # Locked cards are skipped: the arrows only move between pets you own.
            owned = [pet for pet in slot_pets if pet in unlocked_pets]
            position = owned.index(selected_character)
            select_character(owned[(position + direction) % len(owned)])
            return True
    if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
        for pet, rect in zip(slot_pets, character_cards):
            if rect.collidepoint(event.pos):
                select_character(pet)
                return True
        if album_card.collidepoint(event.pos):
            album_open = True
            return True
        if start_button.collidepoint(event.pos):
            flap_or_start()
            return True
        if UPLOAD_FORM_URL and upload_button.collidepoint(event.pos):
            open_upload_form()
            return True
    return False


def handle_death():
    global started, death_started_at, explosion_particles, death_image

    # A collision can touch both a pipe and a screen edge in the same frame.
    if not started:
        return

    track("game_over", pet=get_pilot_id(), run=runs_this_visit, score=score,
          seconds=round((pygame.time.get_ticks() - run_started_at) / 1000),
          dogs_found=len(newly_found_dogs))
    save_progress()
    death_image = get_plane_sprite(shake=True)
    started = False
    death_started_at = pygame.time.get_ticks()
    explosion_particles = []
    for i in range(64):
        angle = math.tau * i / 64
        speed = random.uniform(140, 380)
        explosion_particles.append((
            math.cos(angle) * speed,
            math.sin(angle) * speed,
            random.randint(5, 11),
            random.choice(((255, 230, 80), (255, 150, 35), (255, 75, 30)))
        ))


def draw_death_effect():
    elapsed = (pygame.time.get_ticks() - death_started_at) / 1000
    progress = min(elapsed / (death_duration / 1000), 1)
    center_y = max(bird_radius, min(HEIGHT - bird_radius, bird_y))

    # Draw translucent smoke, shockwaves and fire on a separate effects layer.
    if elapsed < 0.9:
        effects = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        center = (bird_x, int(center_y))
        remaining = 1 - elapsed / 0.9
        for vx, vy, size, color in explosion_particles[::6]:
            smoke_position = (
                int(bird_x + vx * elapsed * 0.3),
                int(center_y + vy * elapsed * 0.2 - elapsed * 45)
            )
            pygame.draw.circle(
                effects, (70, 55, 65, int(100 * remaining)), smoke_position,
                int(10 + elapsed * 30)
            )

        if elapsed < 0.55:
            wave_fade = 1 - elapsed / 0.55
            for scale, color in ((1, (255, 230, 130)), (0.75, (255, 120, 35))):
                pygame.draw.circle(
                    effects, (*color, int(220 * wave_fade)), center,
                    int((20 + elapsed * 260) * scale), max(1, int(7 * wave_fade))
                )

        if elapsed < 0.35:
            radius = 24 + 65 * math.sin(math.pi * elapsed / 0.35)
            for scale, color in ((1, (255, 65, 20)), (0.72, (255, 165, 25)),
                                 (0.4, (255, 245, 170))):
                points = []
                for i in range(24):
                    angle = math.tau * i / 24
                    length = radius * scale * (1 if i % 2 == 0 else 0.6)
                    points.append((bird_x + math.cos(angle) * length,
                                   center_y + math.sin(angle) * length))
                pygame.draw.polygon(effects, (*color, int(255 * (1 - elapsed / 0.35))), points)

        for vx, vy, size, color in explosion_particles:
            position = (
                int(bird_x + vx * elapsed),
                int(center_y + vy * elapsed + 150 * elapsed ** 2)
            )
            trail_start = (int(position[0] - vx * 0.035), int(position[1] - vy * 0.035))
            pygame.draw.line(effects, (*color, int(220 * remaining)), trail_start, position, 2)
            pygame.draw.circle(
                effects, (*color, int(255 * remaining)), position, max(1, int(size * remaining))
            )
        screen.blit(effects, (0, 0))

    flipped_bird = pygame.transform.rotate(death_image, -180 * min(elapsed / 0.6, 1))
    display_y = center_y - 45 * math.sin(math.pi * progress) + 50 * progress ** 2
    display_y = max(bird_radius, min(HEIGHT - bird_radius, display_y))
    screen.blit(flipped_bird, flipped_bird.get_rect(center=(bird_x, int(display_y))))

    if elapsed < 0.7:
        text_scale = 4 + int(2 * min(elapsed / 0.1, 1))
        text_size = (boom_text.get_width() * text_scale, boom_text.get_height() * text_scale)
        text = pygame.transform.scale(boom_text, text_size)
        shadow = pygame.transform.scale(boom_shadow, text_size)
        text_rect = text.get_rect(center=(bird_x + 30, int(center_y - 75 - elapsed * 35)))
        text_rect.clamp_ip(screen.get_rect().inflate(-12, -12))
        text.set_alpha(int(255 * min(1, (0.7 - elapsed) / 0.2)))
        shadow.set_alpha(text.get_alpha())
        screen.blit(shadow, text_rect.move(4, 4))
        screen.blit(text, text_rect)


def get_shake_offset(elapsed):
    # A hard jolt that dies away quickly, like a phone buzzing in the hand.
    if elapsed >= shake_duration:
        return (0, 0)
    strength = shake_strength * (1 - elapsed / shake_duration) ** 2
    return (round(math.sin(elapsed * 120) * strength),
            round(math.cos(elapsed * 97) * strength))


def shake_screen():
    # Shake only the rendered scene; the collision coordinates never move.
    elapsed = (pygame.time.get_ticks() - death_started_at) / 1000
    offset = get_shake_offset(elapsed)
    if offset != (0, 0):
        # The unmoved picture stays underneath, so no gap shows at the edges.
        screen.blit(screen.copy(), offset)
    if elapsed < 0.08:
        screen.fill((90, 40, 30), special_flags=pygame.BLEND_RGB_ADD)  # A brief hot flash.


def update_scenery():
    global world_scroll, current_theme, previous_theme, theme_fade
    global score_pop_frames, ambient_frames
    if not paused:
        ambient_frames += 1
    if started and not paused:
        world_scroll += get_difficulty(score)[1]
        for puff in flap_puffs:
            puff[0] -= 4
            puff[2] += 1
        flap_puffs[:] = [puff for puff in flap_puffs if puff[2] < 24]
        score_pop_frames = max(0, score_pop_frames - 1)
    elif on_character_screen():
        world_scroll += 0.8  # Let the city drift gently behind the menu.

    target_theme = score // points_per_theme % len(SKY_THEMES)
    if target_theme != current_theme:
        previous_theme = current_theme
        current_theme = target_theme
        theme_fade = 0.0
    elif previous_theme is not None and not paused:
        theme_fade = min(1.0, theme_fade + 1 / theme_fade_frames)
        if theme_fade == 1.0:
            previous_theme = None
    sync_page_sky()


def sync_page_sky():
    # The web page behind the game shows the same sky as the game.
    global page_theme
    if IS_WEB and page_theme != current_theme:
        page_theme = current_theme
        platform.document.body.setAttribute("data-theme", str(current_theme))


def blit_wrapped(layer, y, speed_factor, alpha):
    # Distant layers move more slowly, which makes the flat scene feel deep.
    offset = int(world_scroll * speed_factor) % WIDTH
    # Changing a layer's see-through level is slow, so only do it when it really changes.
    if layer.get_alpha() != alpha:
        layer.set_alpha(alpha, pygame.RLEACCEL)
    screen.blit(layer, (-offset, y))
    screen.blit(layer, (WIDTH - offset, y))


def get_scene_layers():
    if previous_theme is None:
        return [(scenery[current_theme], 255)]
    return [(scenery[previous_theme], 255),
            (scenery[current_theme], round(255 * theme_fade))]


def get_sun_and_moon_layers():
    if previous_theme is None:
        return [(scenery[current_theme]["body"], 255)]
    # The old one leaves during the first half and the new one arrives in the second,
    # so they are never both on screen.
    return [(scenery[previous_theme]["body"], round(255 * max(0, 1 - theme_fade * 2))),
            (scenery[current_theme]["body"], round(255 * max(0, theme_fade * 2 - 1)))]


def draw_background():
    layers = get_scene_layers()
    for scene, alpha in layers:
        # A fully solid sky skips the see-through math, which saves a lot in the browser.
        sky_alpha = None if alpha == 255 else alpha
        if scene["sky"].get_alpha() != sky_alpha:
            scene["sky"].set_alpha(sky_alpha)
        screen.blit(scene["sky"], (0, 0))
    for body, alpha in get_sun_and_moon_layers():
        body.set_alpha(alpha)
        screen.blit(body, body.get_rect(center=sky_body_center))
    for scene, alpha in layers:
        blit_wrapped(scene["clouds"], 10, 0.1, alpha)
    for scene, alpha in layers:
        blit_wrapped(scene["far"], HEIGHT - 260, 0.2, alpha)
    for scene, alpha in layers:
        blit_wrapped(scene["near"], HEIGHT - 190, 0.4, alpha)
    theme = SKY_THEMES[current_theme]
    draw_ground_animals(theme["tint"])
    if theme["stars"]:
        draw_fireflies()
    else:
        draw_daytime_animals()


def draw_fireflies():
    # Each firefly follows its own wave and glows on and off as time passes.
    time = ambient_frames / 60
    for index in range(14):
        x = (index * 61 - world_scroll * 0.3 + 18 * math.sin(time + index)) % WIDTH
        y = 400 + index * 13 % 150 + 12 * math.sin(time * 1.4 + index * 2)
        if math.sin(time * 2 + index * 1.7) > -0.2:
            pygame.draw.rect(screen, (150, 170, 70), (int(x) - 2, int(y) - 2, 8, 8))
            pygame.draw.rect(screen, (246, 250, 140), (int(x), int(y), 4, 4))


def draw_daytime_animals():
    # A small flock crosses the sky, then loops around to the other side.
    for index, (x_offset, y_offset) in enumerate(((0, 0), (46, -18), (92, 10))):
        x = WIDTH + 120 - (ambient_frames * 1.5 + x_offset) % (WIDTH + 320)
        y = 76 + y_offset + 10 * math.sin(ambient_frames / 40 + index)
        wing_frame = (ambient_frames // 10 + index) % 2
        screen.blit(get_sprite("bird", wing_frame, 2), (int(x), int(y)))
    # Butterflies flap quickly while drifting in loose waves over the meadow.
    for index in range(5):
        x = (index * 173 + 40 - world_scroll * 0.6
             + 30 * math.sin(ambient_frames / 45 + index)) % WIDTH
        y = 455 + index * 19 % 70 + 14 * math.sin(ambient_frames / 28 + index * 2)
        wing_frame = (ambient_frames // 7 + index) % 2
        screen.blit(get_sprite("butterfly", wing_frame, 2), (int(x), int(y)))


def draw_ground_animals(tint):
    # A fox trots slower than the world scrolls, and a rabbit hops along behind it.
    span = WIDTH + 240
    fox_x = (ambient_frames * 1.1 - world_scroll * 0.55 + 330) % span - 120
    frame = ambient_frames // 8 % 2
    screen.blit(get_sprite("running_fox", frame, 3, tint), (int(fox_x), HEIGHT - 58))
    rabbit_x = (ambient_frames * 0.7 - world_scroll * 0.55 + 40) % span - 120
    hop = abs(math.sin(ambient_frames / 14)) * 16
    screen.blit(get_sprite("rabbit", get_blink_frame(2), 2, tint),
                (int(rabbit_x), int(HEIGHT - 60 - hop)))


def draw_foreground():
    for scene, alpha in get_scene_layers():
        blit_wrapped(scene["foreground"], HEIGHT - 30, 1.0, alpha)


def draw_flying_plane():
    plane_sprite = paused_plane if paused else get_plane_sprite(shake=started)
    # Tilt the picture with the climb or dive; the collision box does not rotate.
    tilted = pygame.transform.rotate(plane_sprite, -bird_velocity * plane_tilt_per_speed)
    screen.blit(tilted, tilted.get_rect(center=(bird_x, int(bird_y))))


def draw_flap_puffs():
    for x, y, age in flap_puffs:
        size = 14 - age // 2
        pygame.draw.rect(screen, INK, (x - size // 2 - 2, y - size // 2 - 2, size + 4, size + 4))
        pygame.draw.rect(screen, CREAM, (x - size // 2, y - size // 2, size, size))


def draw_hud():
    plate = pygame.Rect(14, 14, 170, 76)
    draw_pixel_panel(plate)
    draw_text("得分", 2, (54, 38))
    draw_text(str(score), 4 if score_pop_frames else 3, (128, 36), RED)
    draw_text(f"最高 {best_score}", 2, (plate.centerx, 69), FOREST)
    draw_next_friend_progress()
    if dog_message_frames and started and newest_dog is not None:
        draw_new_friend_banner()


def draw_next_friend_progress():
    left = get_pillars_left()
    if left is None:
        return
    needed = get_pillars_needed()
    bar = pygame.Rect(14, 96, 170, 36)
    draw_pixel_panel(bar, CREAM, shadow=3)
    filled = bar.inflate(-8, -8)
    filled.width = round(filled.width * (needed - left) / needed)
    screen.fill(SUN, filled)
    draw_text(f"新伙伴还差{left}" if left else "就在前面！", 2, bar.center)


def draw_new_friend_banner():
    # Slides down from the top edge, then back up, without stopping the flight.
    frames_shown = dog_message_duration - dog_message_frames
    hidden = max(0, 12 - frames_shown, 12 - dog_message_frames)
    banner = pygame.Rect(240, 14 - hidden * 8, 320, 70)
    draw_pixel_panel(banner, SUN, shadow=4)
    hop = abs(round(math.sin(frames_shown / 6) * 5))
    portrait = get_fitted_portrait(newest_dog, 58, 70)
    screen.blit(portrait, portrait.get_rect(center=(banner.x + 50, banner.centery - hop)))
    draw_text("新伙伴登机！", 2, (banner.x + 200, banner.y + 22), DARK_RED)
    draw_text(CHARACTERS[newest_dog][0], 2, (banner.x + 200, banner.y + 50))


def draw_celebration():
    if celebration_frames:
        grown = celebration_duration - celebration_frames
        for ring in (0, 10):
            radius = 24 + max(0, grown - ring) * 4
            pygame.draw.circle(screen, SUN if ring else CREAM, (bird_x, int(bird_y)), radius, 4)
        if grown < 6:
            screen.fill((40, 40, 25), special_flags=pygame.BLEND_RGB_ADD)  # A brief bright flash.
    for piece in confetti_pieces:
        screen.fill(piece["color"], (int(piece["x"]), int(piece["y"]), piece["size"], piece["size"]))


def draw_pet_card(card, pet, number, selected):
    name, _, intro = CHARACTERS[pet]
    portrait = character_portraits[pet]
    draw_pixel_panel(card, SUN if selected else CREAM)
    screen.blit(portrait, portrait.get_rect(center=(card.x + 44, card.y + 74)))
    badge = pygame.Rect(card.x + 8, card.y + 8, 30, 30)
    draw_pixel_panel(badge, LEAF if selected else SAND, shadow=0)
    draw_text(str(number), 2, badge.center, CREAM if selected else INK)
    text_x = card.x + 135
    draw_text(name, 2, (text_x, card.y + 32))
    # The loop draws one line of the introduction at a time.
    for line_number, line in enumerate(intro):
        draw_text(line, 2, (text_x, card.y + 68 + line_number * 26),
                  INK if selected else FOREST)


def draw_locked_card(card, pet, number):
    draw_pixel_panel(card, SAND)
    silhouette = get_silhouette(pet)
    screen.blit(silhouette, silhouette.get_rect(center=(card.x + 44, card.y + 74)))
    badge = pygame.Rect(card.x + 8, card.y + 8, 30, 30)
    draw_pixel_panel(badge, CREAM, shadow=0)
    draw_text(str(number), 2, badge.center)
    draw_text("？？？", 2, (card.x + 135, card.y + 50))
    draw_text("飞行中", 2, (card.x + 135, card.y + 80), DARK_RED)
    draw_text("可遇到", 2, (card.x + 135, card.y + 104), DARK_RED)


def draw_album_card(card):
    draw_pixel_panel(card, LEAF)
    badge = pygame.Rect(card.x + 8, card.y + 8, 30, 30)
    draw_pixel_panel(badge, SAND, shadow=0)
    draw_text("8", 2, badge.center)
    draw_text("狗狗图鉴", 2, (card.centerx + 16, card.y + 40), CREAM)
    draw_text(f"{len(unlocked_pets)} / {len(PETS)}", 3, (card.centerx, card.y + 86), SUN, INK)


def draw_album():
    ribbon = pygame.Rect(236, 16, 328, 62)
    draw_pixel_panel(ribbon, LEAF)
    draw_text("狗狗图鉴", 3, ribbon.center, CREAM)
    draw_text(f"已收集 {len(unlocked_pets)} / {len(PETS)}，点击已解锁的狗狗就能换它出战",
              2, (400, 104), CREAM, INK)
    for position, pet in enumerate(get_album_page_pets()):
        if pet in unlocked_pets:
            draw_pet_card(character_cards[position], pet, position + 1, pet == selected_character)
        else:
            draw_locked_card(character_cards[position], pet, position + 1)
    pages = (len(PETS) - 1) // album_page_size + 1
    for button, label in ((album_previous_button, "上一页"), (album_next_button, "下一页")):
        draw_pixel_panel(button, CREAM, shadow=4)
        draw_text(label, 2, button.center)
    draw_text(f"第 {album_page + 1} / {pages} 页", 2, (400, 418), CREAM, INK)
    draw_pixel_panel(start_button, LEAF)
    draw_text("返回选角 · 按 Esc", 3, start_button.center, CREAM)


def draw_character_selection():
    ticks = pygame.time.get_ticks()
    # A sine wave swings smoothly between -1 and 1, which makes things bob.
    bob = round(math.sin(ticks / 300) * 4)

    ribbon = pygame.Rect(236, 16, 328, 62)
    draw_pixel_panel(ribbon, LEAF)
    draw_text("选择你的飞行搭档", 3, ribbon.center, CREAM)
    draw_text("点击角色或按 1～8 选择", 2, (400, 104), CREAM, INK)
    plane = get_plane_sprite(shake=True)
    screen.blit(plane, plane.get_rect(center=(150, 78 + bob)))

    mouse_position = pygame.mouse.get_pos()
    for number, (pet, rect) in enumerate(zip(get_slot_pets(), character_cards), 1):
        if pet not in unlocked_pets:
            draw_locked_card(rect, pet, number)
            continue
        selected = pet == selected_character
        hovered = rect.collidepoint(mouse_position)
        # Only the picture lifts; the clickable rectangle stays where it was.
        draw_pet_card(rect.move(0, bob - 6 if selected else -4 if hovered else 0),
                      pet, number, selected)
    draw_album_card(album_card.move(0, -4 if album_card.collidepoint(mouse_position) else 0))

    name, _, intro = CHARACTERS[selected_character]
    # Little animals perch on the cards, which rest on their top edge.
    for animal, card_index, x_offset in (("fox", 0, 32), ("hedgehog", 1, 24),
                                         ("frog", 2, 168), ("rabbit", 3, 126)):
        sprite = get_sprite(animal, get_blink_frame(card_index))
        perch = character_cards[card_index]
        lift = bob - 6 if get_slot_pets()[card_index] == selected_character else 0
        screen.blit(sprite, sprite.get_rect(midbottom=(perch.x + x_offset, perch.top + lift + 3)))
    for animal, center_x in (("squirrel", 56), ("duckling", 744)):
        sprite = get_sprite(animal, get_blink_frame(center_x))
        screen.blit(sprite, sprite.get_rect(midbottom=(center_x, HEIGHT - 8)))

    draw_text(f"{name}：{''.join(intro)}   ·   最高分：{best_score}", 2, (400, 402), SUN, INK)
    if selected_character == welcome_pet:
        draw_text(f"欢迎登机，{name}！按空格键马上起飞", 2, (400, 430), SUN, INK)
    else:
        draw_text("操控飞机，穿过土块，接上柱子上的“？？？”新伙伴！", 2, (400, 430), CREAM, INK)

    pressed = ticks // 500 % 2  # Alternate every half second to invite a press.
    button = start_button.move(0, 2 * pressed)
    draw_pixel_panel(button, LEAF, shadow=6 - 2 * pressed)
    draw_text("开始游戏 · 按空格键", 3, button.center, CREAM)
    if UPLOAD_FORM_URL:
        hovered = upload_button.collidepoint(mouse_position)
        upload = upload_button.move(0, -2 if hovered else 0)
        draw_pixel_panel(upload, SUN if hovered else CREAM, shadow=4)
        draw_text("上传我的宠物！", 2, upload.center)
    # A solid plate keeps the instructions readable while animals wander behind it.
    draw_pixel_panel(pygame.Rect(108, 510, 584, 66), shadow=4)
    draw_text("空格键：上升  |  P：暂停／继续  |  R：返回选角", 2, (400, 528))
    footer = "关闭窗口退出" if score_storage_available else "最高分仅在本次运行中保留"
    draw_text(footer, 2, (400, 556), FOREST)


@lru_cache(maxsize=64)
def get_fitted_portrait(pet, height, maximum_width):
    return fit_character_portrait(character_images[pet], height, maximum_width)


new_dogs_card = pygame.Rect(210, 210, 380, 150)


def draw_falling_confetti():
    # Worked out from the clock, so it needs no list and keeps falling on its own.
    ticks = pygame.time.get_ticks()
    for number in range(48):
        x = (number * 97 + round(math.sin(ticks / 400 + number) * 12)) % WIDTH
        y = (ticks * (0.08 + number % 5 * 0.02) + number * 53) % HEIGHT
        size = 5 + number % 4
        screen.fill(CONFETTI_COLORS[number % len(CONFETTI_COLORS)], (x, int(y), size, size))


def draw_sun_rays(area):
    # Slowly turning rays, kept inside the area so they never run under other text.
    turn = pygame.time.get_ticks() / 1600
    screen.set_clip(area)
    for number in range(12):
        start = turn + math.tau * number / 12
        end = start + math.tau / 24
        pygame.draw.polygon(screen, (255, 206, 90), (
            area.center,
            (area.centerx + math.cos(start) * 400, area.centery + math.sin(start) * 400),
            (area.centerx + math.cos(end) * 400, area.centery + math.sin(end) * 400),
        ))
    screen.set_clip(None)


def draw_only_new_dog(area, pet):
    name, _, intro = CHARACTERS[pet]
    portrait = get_fitted_portrait(pet, 92, 110)
    hop = abs(round(math.sin(pygame.time.get_ticks() / 180) * 6))
    screen.blit(portrait, portrait.get_rect(center=(area.x + 76, area.centery - hop)))
    draw_text(name, 3, (area.x + 242, area.y + 30))
    draw_text("".join(intro), 2, (area.x + 242, area.y + 76), FOREST)


def draw_one_of_many_new_dogs(cell, pet, large):
    name, _, intro = CHARACTERS[pet]
    if pet == selected_character:
        pygame.draw.rect(screen, CREAM, cell.inflate(-4, -2))
    # Large cells have room for the introduction; small ones show only the name.
    portrait = get_fitted_portrait(pet, 56 if large else cell.height - 18, cell.width - 8)
    screen.blit(portrait, portrait.get_rect(midtop=(cell.centerx, cell.y + 2)))
    if large:
        draw_text(name, 2, (cell.centerx, cell.y + 70))
        draw_text("".join(intro), 1, (cell.centerx, cell.y + 92), FOREST)
    else:
        draw_text(name, 1, (cell.centerx, cell.bottom - 8))


def draw_new_dogs():
    found = newly_found_dogs
    card = new_dogs_card
    draw_pixel_panel(card, SUN, shadow=4)
    heading = "新伙伴登机！" if len(found) == 1 else f"本局解锁 {len(found)} 位新伙伴！"
    draw_text(heading, 2, (card.centerx, card.y + 22), DARK_RED)
    area = pygame.Rect(card.x + 8, card.y + 38, card.width - 16, card.height - 46)
    if len(found) == 1:
        draw_only_new_dog(area, found[0])
    else:
        # A longer list simply makes more, smaller cells, so every dog always fits.
        rows = 1 if len(found) <= 3 else 2
        columns = math.ceil(len(found) / rows)
        cell_size = (area.width // columns, area.height // rows)
        for position, pet in enumerate(found):
            row, column = divmod(position, columns)
            cell = pygame.Rect(area.x + column * cell_size[0], area.y + row * cell_size[1], *cell_size)
            draw_one_of_many_new_dogs(cell, pet, large=rows == 1)

    if selected_character in found:
        name = CHARACTERS[selected_character][0]
        note = f"已换上{name}" if len(found) == 1 else f"已换上{name}，按 C 换下一只"
        draw_text(note, 2, (400, 384), FOREST)
    else:
        draw_text("按 C 换它出战" if len(found) == 1 else "按 C 挑一只出战", 2, (400, 384), DARK_RED)
    draw_text("按空格键再来一次", 2, (400, 412))
    draw_text("R：返回选角", 2, (400, 438), FOREST)


def draw_message_panel():
    if on_character_screen():
        draw_album() if album_open else draw_character_selection()
        return
    overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
    overlay.fill((*INK, 120))
    screen.blit(overlay, (0, 0))
    if game_over and newly_found_dogs:
        draw_falling_confetti()
    panel = pygame.Rect(170, 130, 460, 340)
    ribbon = pygame.Rect(210, 96, 380, 72)
    draw_pixel_panel(panel)
    draw_pixel_panel(ribbon, RED if game_over else LEAF)

    if paused:
        draw_text("暂停一下", 4, ribbon.center, CREAM)
        draw_text(f"得分：{score}", 3, (400, 240))
        draw_text("按 P 继续飞行", 3, (400, 310), DARK_RED)
        draw_text("R：返回选角  |  关闭窗口退出", 2, (400, 400), FOREST)
    elif game_over and newly_found_dogs:
        draw_text("坠机啦！", 4, ribbon.center, CREAM)
        record_note = "  新纪录！" if new_best else ""
        draw_text(f"本局 {score}  ·  最高 {best_score}{record_note}", 2, (400, 190))
        draw_sun_rays(new_dogs_card.inflate(24, 16))
        draw_new_dogs()
    elif game_over:
        draw_text("坠机啦！", 4, ribbon.center, CREAM)
        draw_text(f"本局得分：{score}", 3, (400, 212))
        draw_text(f"最高分：{best_score}", 3, (400, 262), DARK_RED)
        if new_best:
            record = pygame.Rect(280, 292, 240, 40)
            draw_pixel_panel(record, SUN, shadow=0)
            draw_text("刷新个人纪录！", 2, record.center)
        draw_text("按空格键再来一次", 3, (400, 366))
        draw_text("R：返回选角  |  关闭窗口退出", 2, (400, 412), FOREST)

    for animal, center_x in (("fox", 204), ("rabbit", 596)):
        sprite = get_sprite(animal, get_blink_frame(center_x), 2)
        screen.blit(sprite, sprite.get_rect(midbottom=(center_x, panel.bottom - 8)))

    if not score_storage_available:
        draw_text("最高分仅在本次运行中保留", 2, (400, 444), DARK_RED)


# The game always moves in steps of one sixtieth of a second, whatever the frame rate.
# A slow computer simply runs several steps per drawing, so the plane keeps its speed.
step_milliseconds = 1000 / 60
step_tolerance = 2  # Frames just under a step still count, which avoids tiny stutters.
maximum_steps_per_frame = 6  # Beyond this the game slows down rather than jumping ahead.
time_bank = 0.0
# Browser clocks wobble even when frames arrive evenly. Averaging the last few frames
# stops that wobble from turning into a skipped or doubled step, which looks like a stutter.
recent_frame_times = deque(maxlen=8)
steady_frame_tolerance = 1.2


def get_steps_due(elapsed_milliseconds):
    global time_bank
    limit = step_milliseconds * maximum_steps_per_frame
    recent_frame_times.append(min(elapsed_milliseconds, limit))
    average = sum(recent_frame_times) / len(recent_frame_times)
    time_bank = min(time_bank + average, limit)
    # A steady 60 Hz screen gets exactly one step per frame. The small leftover time
    # fades away, so it can never build up into a skipped or doubled step.
    if abs(average - step_milliseconds) < steady_frame_tolerance:
        time_bank = (time_bank - step_milliseconds) * 0.9
        return 1
    steps = int((time_bank + step_tolerance) / step_milliseconds)
    time_bank -= steps * step_milliseconds
    return steps


def update_game_step():
    global score, score_pop_frames, pillars_since_dog, dog_message_frames
    if not paused:
        update_celebration()  # Runs after a crash too, so the confetti finishes falling.
    if started and not paused:

        # Gentle gravity with a capped falling speed.
        update_bird()

        # Move pipes
        move_pipes(score)

        # Add new pipes
        if pipes[-1][0].x < WIDTH - pipe_spacing:
            new_pair = create_pipe(score, get_gap_center(pipes[-1]))
            if not assign_dog(new_pair):
                assign_creature(new_pair)
            pipes.append(new_pair)

        # Remove old pipes
        if pipes[0][0].right < 0:
            pipes.pop(0)
            score += 1
            score_pop_frames = 12
            pillars_since_dog += 1
            update_best_score()

        collect_passed_dogs()
        dog_message_frames = max(0, dog_message_frames - 1)

        # Bird collision rectangle
        bird_rect = pygame.Rect(
            bird_x - bird_radius,
            bird_y - bird_radius,
            bird_radius * 2,
            bird_radius * 2
        )

        # Pipe collision
        for top_pipe, bottom_pipe in pipes:

            if (
                bird_rect.colliderect(top_pipe)
                or bird_rect.colliderect(bottom_pipe)
            ):
                handle_death()
                break

        # Screen boundary collision
        if bird_y - bird_radius < 0:
            handle_death()

        if bird_y + bird_radius > HEIGHT:
            handle_death()

    update_scenery()


async def run_game():
    global game_over
    global best_score, score_storage_available
    global paused, paused_plane

    try:
        best_score = load_best_score()
    except STORAGE_ERRORS:
        score_storage_available = False
    load_progress()
    running = True
    reset_game()
    apply_pet_link(get_linked_pet_id())
    track("game_ready", pet=get_pilot_id(), pets_unlocked=len(unlocked_pets))
    last_tick = pygame.time.get_ticks()

    while running:

        # -------------------------
        # Events
        # -------------------------
        for event in pygame.event.get():

            if event.type == pygame.QUIT:
                running = False

            if handle_character_selection(event):
                continue

            if event.type == pygame.KEYDOWN:

                if event.key == pygame.K_p and started:
                    paused = not paused
                    paused_plane = get_plane_sprite(shake=True) if paused else None

                if event.key == pygame.K_c:
                    use_new_dog()

                if event.key == pygame.K_SPACE:
                    flap_or_start()

                if event.key == pygame.K_r:
                    reset_game()

        # -------------------------
        # Game logic
        # -------------------------
        now = pygame.time.get_ticks()
        for _ in range(get_steps_due(now - last_tick)):
            update_game_step()
        last_tick = now

        if death_started_at is not None:
            if pygame.time.get_ticks() - death_started_at >= death_duration:
                game_over = True

        # -------------------------
        # Drawing
        # -------------------------
        draw_background()

        # Draw animals first, so ducking moves them behind their soil blocks.
        draw_creatures()
        draw_waiting_dogs()

        # Draw soil blocks using the existing obstacle rectangles.
        for top_pipe, bottom_pipe in pipes:
            screen.blit(
                get_obstacle_image(top_pipe.width, top_pipe.height, ceiling=True),
                top_pipe.topleft
            )

            screen.blit(
                get_obstacle_image(bottom_pipe.width, bottom_pipe.height),
                bottom_pipe.topleft
            )

        draw_foreground()

        # Draw bird
        if death_started_at is not None:
            draw_death_effect()
        elif not on_character_screen():
            draw_flap_puffs()
            draw_flying_plane()
        draw_celebration()

        # The menu has its own score line, so only show this plate during a run.
        if not on_character_screen():
            draw_hud()

        # After the score plate, so the whole picture jolts together.
        if death_started_at is not None:
            shake_screen()

        if paused or (not started and (death_started_at is None or game_over)):
            draw_message_panel()

        pygame.display.update()

        clock.tick(60)
        # Hand control back to the browser each frame so the page keeps drawing.
        await asyncio.sleep(0)

    pygame.quit()


def main():
    asyncio.run(run_game())


if __name__ == "__main__":
    asyncio.run(run_game())
